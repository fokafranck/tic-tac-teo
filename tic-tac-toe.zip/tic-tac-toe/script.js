let store = {
    matchId: 'identifiant',
    boardState: [
        "-", "-", "-",
        "-", "-", "-",
        "-", "-", "-"
    ],
    lastMove: null,
    activePlayer: 'o',
    gameOver: false,
    delayMachine: 1500
};

const init = () => {
    if (Math.random() < 0.5) {
        store.activePlayer = 'x';
        playMachine();
    }

    renderBoard();
    RefreshPlayer();

}

const shuffle = (array) => {
    let currentIndex = array.length;
    let randomIndex;

    while (0 !== currentIndex) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex--;

        [array[currentIndex], array[randomIndex]] = [array[randomIndex], array[currentIndex]]
    }

    return array;
}


const RefreshPlayer = () => {
    document.querySelector('#currentPlayer').innerHTML = store.activePlayer.toUpperCase();
    const rows = document.querySelectorAll('.player');
    store.activePlayer == 'x' ? rows[0].className = 'player active' : rows[0].className = 'player'
    store.activePlayer == 'o' ? rows[1].className = 'player active' : rows[1].className = 'player'
}

const playMachine = () => {
    const availables = store.boardState.map((bcase, index) => bcase == '-' ? index : -1).filter((icase => icase != -1));
    const indexToPlay = shuffle(availables)[0];
    play(indexToPlay, 'x');
}

const play = (position, player = 'o') => {
    if (!store.gameOver) {
        if (store.boardState[position] != '-' || store.activePlayer != player) {
            return false;
        } else {
            store.boardState[position] = player.toUpperCase();
            store.activePlayer = player == 'x' ? 'o' : 'x';

            store.lastMove = { char: player, position: position };
            renderBoard();
            RefreshPlayer();

            if (isGameOver()) {
                const winner = aWinner();
                if (winner) {
                    let chaine = winner == 'X' ? "L'ordinateur a win !" : 'Vous avez win !';
                    alert("Partie terminee !\n" + chaine);
                } else {
                    alert("Partie terminee ! \n Match Nul !");
                }
            } else {
                if (player == 'o') {
                    setTimeout(() => {
                        RefreshPlayer();
                        playMachine();
                    }, store.delayMachine);
                }
            }

        }
    } else {
        if (confirm("La partie est terminee ! Rejouer ?")) {
            location.reload();
        }
    }

    console.log(store);
}

const createRow = () => {
    const elem = document.createElement('div');
    elem.className = 'row';

    return elem
}

const renderBoard = () => {
    let k = 0;
    let j = 0;

    const gameZone = document.querySelector("#gameZone");
    gameZone.innerHTML = '';

    gameZone.appendChild(createRow());
    gameZone.appendChild(createRow());
    gameZone.appendChild(createRow());

    const rows = document.querySelectorAll('.row');

    for (let i = 0; i < store.boardState.length; i++) {
        const element = store.boardState[i];
        const currentRow = rows[k];
        const child = document.createElement('div');

        element != '-' && (child.innerHTML = element.toUpperCase());
        element == 'O' && (child.className = 'white');

        child.onclick = () => { play(i); };

        currentRow.appendChild(child);

        if (((i + 1) % 3) == 0) {
            k++;
            j = 0;
        }

        j++;
    }
}

const isGameOver = () => {
    const availables = store.boardState.filter((bcase => bcase == '-'));
    if (availables.length == 0 || aWinner()) {
        store.gameOver = true;
        return true
    }

    return false;
}

const aWinner = () => {

    const possibles = ["012", "345", "678", "036", "147", "258", "048", "246"];

    for (const possible of possibles) {
        const indexes = possible.split('');

        let somme = '';

        indexes.forEach(index => {
            store.boardState[index] != '-' && (somme += store.boardState[index]);
        });

        if (somme.split(store.boardState[indexes[0]]).length == 4) {
            return somme[0];
        }
    }

    return false;

}

init();